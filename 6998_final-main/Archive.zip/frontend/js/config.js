// config.js
var poolData = {
    UserPoolId: 'us-east-1_BECu2guMV', // Please provide yours
    ClientId: '29jdko87pieokdk4b1bradhr5s', // Please provide yours
    };